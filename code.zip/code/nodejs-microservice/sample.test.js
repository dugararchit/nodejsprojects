const request = require("supertest");
const url = "http://localhost:4000";

describe("Post Endpoints", () => {
  it("should show the connection with hello world", async () => {
    const res = await request(url).get("/");
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty("success");
  });
});

describe("My API tests", () => {
  let token;

  beforeAll((done) => {
    request("http://13.95.64.501")
      .post("/v1.0/invoke/accountapp/method/api/v1/client/account/login")
      .send({
        emailAddress: "asd@gmail.com",
        passwordHash: "arc",
      })
      .end((err, response) => {
        token = response.body.token; // save the token!
        done();
      });
  });

  it("should token with boq listing", (done) => {
    request("http://13.95.64.501")
      .get("/v1.0/invoke/boqapp/method/api/v1/client/boqListing")
      .set("Authorization", "Bearer " + token)
      .end((err, response) => {
        console.log(response.body);
        done();
      });
  });
});
